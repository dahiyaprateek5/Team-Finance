import sys
import os
sys.path.append('DATABASE_CONNECTION')
from db_connection import DatabaseConnection
from db_operations import DatabaseOperations

# Database connection instance
db_conn = DatabaseConnection()
db_ops = DatabaseOperations(db_conn)