# =====================================
# File: app.py (FIXED VERSION)
# Complete Flask Application for Financial Risk Assessment
# Fixed PostgreSQL Cash Flow Data Integration
# =====================================

"""
Flask Application for Financial Risk Assessment
Integrates XGBoost, Random Forest, Neural Networks, and LightGBM
Enhanced with PostgreSQL Cash Flow Data Fetching - FIXED
"""

import os
import sys
import warnings
warnings.filterwarnings('ignore')

# Add project root to path
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from flask import Flask, request, jsonify, render_template, send_file 
import numpy as np 
import pandas as pd  
from datetime import datetime
import traceback
from typing import Dict, List, Any, Optional


# Import your database classes 
try:
    from db_connection import DatabaseConnection  # Your database connection class
    from db_models import DatabaseModels, setup_database  # Your database models
    from db_operations import DatabaseOperations  # Your database operations
    DATABASE_CLASSES_AVAILABLE = True
    print("✅ Database classes imported successfully")
except ImportError as e:
    print(f"⚠️ Database classes not available: {e}")
    print(f"Make sure you have: db_connection.py, db_models.py, db_operations.py")
    DATABASE_CLASSES_AVAILABLE = False

# Try to import ML algorithms
try:
    from ml_algorithms.xgboost import XGBRegressorModel, XGBClassifierModel, XGBConfig  
    XGBOOST_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ XGBoost not available: {e}")
    XGBOOST_AVAILABLE = False

try:
    from ml_algorithms.random_forest import RandomForestRegressorModel, RandomForestClassifierModel, RandomForestConfig
    RANDOM_FOREST_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ Random Forest not available: {e}")
    RANDOM_FOREST_AVAILABLE = False

try:
    from ml_algorithms.neural_networks import NeuralNetworkRegressor, NeuralNetworkClassifier, NeuralNetworkConfig
    NEURAL_NETWORKS_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ Neural Networks not available: {e}")
    NEURAL_NETWORKS_AVAILABLE = False

try:
    from ml_algorithms.lightgbm import LGBRegressorModel, LGBClassifierModel, LGBConfig
    LIGHTGBM_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ LightGBM not available: {e}")
    LIGHTGBM_AVAILABLE = False

try:
    from ml_algorithms.essemble_manager import EnsembleManager  
    ENSEMBLE_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ Ensemble Manager not available: {e}")
    ENSEMBLE_AVAILABLE = False

try:
    from ml_algorithms.model_evaluation import (
        RegressionMetrics, ClassificationMetrics, 
        CrossValidator, PerformanceTracker
    )
    EVALUATION_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ Model Evaluation not available: {e}")
    EVALUATION_AVAILABLE = False

try:
    from utils.ml_predictor import MLPredictor, format_confidence_response, get_confidence_recommendations
    CONFIDENCE_UTILS_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ Confidence utilities not available: {e}")
    CONFIDENCE_UTILS_AVAILABLE = False

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'financial-risk-assessment-2024'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Global variables for models and performance tracking
models = {}
performance_tracker = None
ensemble_manager = None
ml_predictor = None
db_connection = None
db_operations = None

# ===========================================
# DATABASE CONNECTION AND MANAGEMENT (FIXED)
# ===========================================

def initialize_database():
    """Initialize database connection using your actual classes"""
    global db_connection, db_operations
    
    if not DATABASE_CLASSES_AVAILABLE:
        print("❌ Database classes not available - database features disabled")
        return False
    
    try:
        # Initialize your database connection
        db_connection = DatabaseConnection()
        
        # Test connection
        if db_connection.connect():
            print("✅ Database connection established")
            
            # Test the connection
            if db_connection.test_connection():
                print("✅ Database connection test successful")
                
                # Initialize database operations
                db_operations = DatabaseOperations(db_connection)
                print("✅ Database operations initialized")
                
                # Check if tables exist and create if needed
                setup_database_if_needed()
                
                return True
            else:
                print("❌ Database connection test failed")
                return False
        else:
            print("❌ Failed to establish database connection")
            return False
            
    except Exception as e:
        print(f"❌ Database initialization failed: {e}")
        return False

def setup_database_if_needed():
    """Setup database tables if they don't exist"""
    try:
        if not db_connection:
            return False
        
        # Check if cash_flow_statement table exists
        if not db_connection.table_exists('cash_flow_statement'):
            print("🔧 Setting up database tables...")
            success = setup_database(db_connection)
            if success:
                print("✅ Database setup completed")
            else:
                print("❌ Database setup failed")
            return success
        else:
            print("✅ Database tables already exist")
            return True
            
    except Exception as e:
        print(f"❌ Database setup error: {e}")
        return False

# ===========================================
# CASH FLOW DATA FETCHING FUNCTIONS (FIXED)
# ===========================================

def fetch_company_cash_flow_data(company_name=None, company_id=None, year=None, limit=100):
    """
    Fetch cash flow statement data from PostgreSQL using your exact table structure
    
    Args:
        company_name (str): Company name to filter
        company_id (int): Company ID to filter
        year (int): Specific year to filter
        limit (int): Maximum number of records to return
    
    Returns:
        list: Cash flow data records
    """
    if not db_connection:
        raise Exception("Database not connected")
    
    try:
        # Base query for your exact cash_flow_statement table structure
        base_query = """
        SELECT 
            id,
            company_id,
            year,
            generated_at,
            company_name,
            industry,
            net_income,
            depreciation_and_amortization,
            stock_based_compensation,
            changes_in_working_capital,
            accounts_receivable,
            inventory,
            accounts_payable,
            net_cash_from_operating_activities,
            capital_expenditures,
            acquisitions,
            net_cash_from_investing_activities,
            dividends_paid,
            share_repurchases,
            net_cash_from_financing_activities,
            free_cash_flow,
            ocf_to_net_income_ratio,
            liquidation_label,
            debt_to_equity_ratio,
            interest_coverage_ratio
        FROM cash_flow_statement
        WHERE 1=1
        """
        
        params = []
        conditions = []
        
        # Add filters based on parameters
        if company_name:
            conditions.append("LOWER(company_name) LIKE LOWER(%s)")
            params.append(f"%{company_name}%")
        
        if company_id:
            conditions.append("company_id = %s")
            params.append(company_id)
        
        if year:
            conditions.append("year = %s")
            params.append(year)
        
        # Combine conditions
        if conditions:
            base_query += " AND " + " AND ".join(conditions)
        
        # Add ordering and limit
        base_query += " ORDER BY company_name, year DESC"
        
        if limit:
            base_query += f" LIMIT {limit}"
        
        # Execute query using your database connection
        results = db_connection.execute_select(base_query, params)
        return results if results else []
    
    except Exception as e:
        print(f"Error fetching cash flow data: {e}")
        raise e

def fetch_company_financial_summary(company_name=None, company_id=None):
    """
    Fetch financial summary for a company across all years
    """
    if not db_connection:
        raise Exception("Database not connected")
    
    try:
        query = """
        SELECT 
            company_name,
            company_id,
            industry,
            COUNT(*) as years_of_data,
            MIN(year) as earliest_year,
            MAX(year) as latest_year,
            
            -- Average Financial Health Metrics
            AVG(net_income) as avg_net_income,
            AVG(net_cash_from_operating_activities) as avg_operating_cash_flow,
            AVG(free_cash_flow) as avg_free_cash_flow,
            AVG(ocf_to_net_income_ratio) as avg_ocf_ratio,
            AVG(debt_to_equity_ratio) as avg_debt_equity_ratio,
            AVG(interest_coverage_ratio) as avg_interest_coverage_ratio,
            
            -- Latest Year Data
            (SELECT net_income FROM cash_flow_statement cf2 
             WHERE cf2.company_name = cf1.company_name 
             AND cf2.year = MAX(cf1.year) LIMIT 1) as latest_net_income,
            
            (SELECT net_cash_from_operating_activities FROM cash_flow_statement cf2 
             WHERE cf2.company_name = cf1.company_name 
             AND cf2.year = MAX(cf1.year) LIMIT 1) as latest_operating_cash_flow,
             
            (SELECT liquidation_label FROM cash_flow_statement cf2 
             WHERE cf2.company_name = cf1.company_name 
             AND cf2.year = MAX(cf1.year) LIMIT 1) as latest_liquidation_risk
             
        FROM cash_flow_statement cf1
        WHERE 1=1
        """
        
        params = []
        
        if company_name:
            query += " AND LOWER(company_name) LIKE LOWER(%s)"
            params.append(f"%{company_name}%")
        
        if company_id:
            query += " AND company_id = %s"
            params.append(company_id)
        
        query += " GROUP BY company_name, company_id, industry"
        
        results = db_connection.execute_select(query, params)
        return results[0] if results else None
        
    except Exception as e:
        print(f"Error fetching financial summary: {e}")
        raise e

def fetch_companies_by_industry(industry=None, limit=50):
    """
    Fetch companies filtered by industry from cash_flow_statement table
    """
    if not db_connection:
        raise Exception("Database not connected")
    
    try:
        query = """
        SELECT DISTINCT
            company_name,
            company_id,
            industry,
            MAX(year) as latest_year,
            COUNT(DISTINCT year) as years_available,
            AVG(liquidation_label) as avg_liquidation_risk,
            AVG(net_income) as avg_net_income,
            AVG(free_cash_flow) as avg_free_cash_flow
        FROM cash_flow_statement
        WHERE 1=1
        """
        
        params = []
        
        if industry:
            query += " AND LOWER(industry) = LOWER(%s)"
            params.append(industry)
        
        query += """
        GROUP BY company_name, company_id, industry
        ORDER BY company_name
        """
        
        if limit:
            query += f" LIMIT {limit}"
        
        results = db_connection.execute_select(query, params)
        return results if results else []
        
    except Exception as e:
        print(f"Error fetching companies by industry: {e}")
        raise e

def get_available_industries():
    """Get all available industries from cash_flow_statement table"""
    if not db_connection:
        raise Exception("Database not connected")
    
    try:
        query = """
        SELECT 
            industry,
            COUNT(DISTINCT company_name) as company_count,
            MIN(year) as earliest_year,
            MAX(year) as latest_year,
            AVG(liquidation_label) as avg_liquidation_risk,
            AVG(net_income) as avg_net_income
        FROM cash_flow_statement
        WHERE industry IS NOT NULL
        GROUP BY industry
        ORDER BY industry
        """
        
        results = db_connection.execute_select(query)
        return results if results else []
        
    except Exception as e:
        print(f"Error fetching industries: {e}")
        raise e

def get_all_companies():
    """Get all unique companies from cash_flow_statement table"""
    if not db_connection:
        raise Exception("Database not connected")
    
    try:
        query = """
        SELECT DISTINCT
            company_name,
            company_id,
            industry,
            MAX(year) as latest_year,
            MIN(year) as earliest_year,
            COUNT(DISTINCT year) as years_available,
            AVG(net_income) as avg_net_income,
            AVG(free_cash_flow) as avg_free_cash_flow,
            AVG(liquidation_label) as avg_liquidation_risk
        FROM cash_flow_statement
        WHERE company_name IS NOT NULL
        GROUP BY company_name, company_id, industry
        ORDER BY company_name
        """
        
        results = db_connection.execute_select(query)
        return results if results else []
        
    except Exception as e:
        print(f"Error fetching all companies: {e}")
        raise e

def calculate_financial_health_score(summary):
    """Calculate a financial health score based on key metrics"""
    try:
        score = 0
        max_score = 100
        
        # Operating Cash Flow Score (30 points)
        ocf = summary.get('avg_operating_cash_flow', 0) or 0
        if ocf > 0:
            score += 30
        elif ocf > -1000000:  # Slightly negative
            score += 15
        
        # Net Income Score (25 points)
        net_income = summary.get('avg_net_income', 0) or 0
        if net_income > 0:
            score += 25
        elif net_income > -500000:
            score += 10
        
        # Debt to Equity Score (25 points)
        debt_equity = summary.get('avg_debt_equity_ratio', 0) or 0
        if debt_equity < 1:
            score += 25
        elif debt_equity < 2:
            score += 15
        elif debt_equity < 3:
            score += 5
        
        # Interest Coverage Score (20 points)
        interest_coverage = summary.get('avg_interest_coverage_ratio', 0) or 0
        if interest_coverage > 5:
            score += 20
        elif interest_coverage > 2.5:
            score += 15
        elif interest_coverage > 1.5:
            score += 10
        elif interest_coverage > 1:
            score += 5
        
        return {
            'score': min(score, max_score),
            'max_score': max_score,
            'grade': 'A' if score >= 80 else 'B' if score >= 60 else 'C' if score >= 40 else 'D',
            'components': {
                'operating_cash_flow': ocf,
                'net_income': net_income,
                'debt_to_equity': debt_equity,
                'interest_coverage': interest_coverage
            }
        }
    
    except Exception as e:
        return {
            'score': 0,
            'max_score': 100,
            'grade': 'F',
            'error': str(e)
        }

# Initialize components
def initialize_components():
    """Initialize ML components and database"""
    global performance_tracker, ensemble_manager, ml_predictor
    
    # Initialize database first
    db_initialized = initialize_database()
    
    try:
        if EVALUATION_AVAILABLE:
            performance_tracker = PerformanceTracker()
            print("✅ Performance Tracker initialized")
        
        if ENSEMBLE_AVAILABLE:
            ensemble_manager = EnsembleManager()
            print("✅ Ensemble Manager initialized")
        
        if CONFIDENCE_UTILS_AVAILABLE:
            ml_predictor = MLPredictor()
            print("✅ ML Predictor with Confidence Support initialized")
            
    except Exception as e:
        print(f"⚠️ Component initialization failed: {e}")
    
    return db_initialized

# ===========================================
# CASH FLOW DATA API ENDPOINTS (FIXED)
# ===========================================

@app.route('/api/cash-flow/companies')
def get_companies_cash_flow():
    """Get companies cash flow data with filtering options - FIXED"""
    try:
        if not db_connection:
            return jsonify({
                'success': False,
                'error': 'Database not connected'
            }), 500
        
        # Get query parameters
        company_name = request.args.get('company_name')
        company_id = request.args.get('company_id', type=int)
        year = request.args.get('year', type=int)
        industry = request.args.get('industry')
        limit = request.args.get('limit', default=100, type=int)
        
        # Fetch data based on filters
        if industry:
            # Filter by industry first, then get cash flow data
            companies = fetch_companies_by_industry(industry, limit)
            
            # Get detailed cash flow data for these companies
            cash_flow_data = []
            for company in companies[:10]:  # Limit to prevent large responses
                company_data = fetch_company_cash_flow_data(
                    company_name=company['company_name'],
                    year=year,
                    limit=3  # Get last 3 years
                )
                if company_data:
                    cash_flow_data.extend(company_data)
            
            return jsonify({
                'success': True,
                'companies_found': len(companies),
                'cash_flow_records': len(cash_flow_data),
                'companies': companies,
                'cash_flow_data': cash_flow_data,
                'filters_applied': {
                    'industry': industry,
                    'year': year
                }
            })
        
        else:
            # Direct cash flow data fetch
            cash_flow_data = fetch_company_cash_flow_data(
                company_name=company_name,
                company_id=company_id,
                year=year,
                limit=limit
            )
            
            return jsonify({
                'success': True,
                'records_found': len(cash_flow_data),
                'cash_flow_data': cash_flow_data,
                'filters_applied': {
                    'company_name': company_name,
                    'company_id': company_id,
                    'year': year
                }
            })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc()
        }), 500

@app.route('/api/cash-flow/company/<company_identifier>')
def get_company_financial_profile(company_identifier):
    """Get comprehensive financial profile for a specific company - FIXED"""
    try:
        if not db_connection:
            return jsonify({
                'success': False,
                'error': 'Database not connected'
            }), 500
        
        # Try to determine if identifier is company_id or company name
        is_id = company_identifier.isdigit()
        
        if is_id:
            summary = fetch_company_financial_summary(company_id=int(company_identifier))
            cash_flow_data = fetch_company_cash_flow_data(company_id=int(company_identifier), limit=10)
        else:
            summary = fetch_company_financial_summary(company_name=company_identifier)
            cash_flow_data = fetch_company_cash_flow_data(company_name=company_identifier, limit=10)
        
        if not summary:
            return jsonify({
                'success': False,
                'error': f'Company "{company_identifier}" not found in database'
            }), 404
        
        # Calculate additional insights
        financial_health_score = calculate_financial_health_score(summary)
        
        return jsonify({
            'success': True,
            'company_summary': summary,
            'financial_health_score': financial_health_score,
            'historical_data': cash_flow_data,
            'data_years': summary.get('years_of_data', 0),
            'latest_year': summary.get('latest_year'),
            'risk_indicators': {
                'liquidation_risk': summary.get('latest_liquidation_risk', 0),
                'debt_level': 'High' if summary.get('avg_debt_equity_ratio', 0) > 2 else 'Moderate' if summary.get('avg_debt_equity_ratio', 0) > 1 else 'Low',
                'cash_flow_stability': 'Stable' if summary.get('avg_operating_cash_flow', 0) > 0 else 'Unstable'
            }
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc()
        }), 500

@app.route('/api/cash-flow/industries')
def get_industries():
    """Get available industries from cash_flow_statement table - FIXED"""
    try:
        if not db_connection:
            return jsonify({
                'success': False,
                'error': 'Database not connected'
            }), 500
        
        data = get_available_industries()
        
        return jsonify({
            'success': True,
            'industries': data,
            'total_industries': len(data)
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/companies/all')
def get_all_companies_api():
    """Get all companies from cash_flow_statement table - NEW ENDPOINT"""
    try:
        if not db_connection:
            return jsonify({
                'success': False,
                'error': 'Database not connected'
            }), 500
        
        companies = get_all_companies()
        
        return jsonify({
            'success': True,
            'companies': companies,
            'total_companies': len(companies)
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/cash-flow/search')
def search_companies():
    """Search companies by name with autocomplete functionality - FIXED"""
    try:
        if not db_connection:
            return jsonify({
                'success': False,
                'error': 'Database not connected'
            }), 500
        
        search_term = request.args.get('q', '')
        limit = request.args.get('limit', default=10, type=int)
        
        if not search_term or len(search_term) < 2:
            return jsonify({
                'success': False,
                'error': 'Search term must be at least 2 characters'
            }), 400
        
        query = """
        SELECT DISTINCT 
            company_name,
            company_id,
            industry,
            MAX(year) as latest_year,
            COUNT(DISTINCT year) as years_available,
            AVG(liquidation_label) as avg_liquidation_risk
        FROM cash_flow_statement
        WHERE LOWER(company_name) LIKE LOWER(%s)
        GROUP BY company_name, company_id, industry
        ORDER BY company_name
        LIMIT %s
        """
        
        results = db_connection.execute_select(query, [f"%{search_term}%", limit])
        
        return jsonify({
            'success': True,
            'search_term': search_term,
            'results': results if results else [],
            'count': len(results) if results else 0
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/cash-flow/train-data')
def get_training_data():
    """Get formatted training data for ML models - FIXED"""
    try:
        if not db_connection:
            return jsonify({
                'success': False,
                'error': 'Database not connected'
            }), 500
        
        # Fetch all cash flow data for training
        query_params = request.args
        year = query_params.get('year', type=int)
        industry = query_params.get('industry')
        limit = query_params.get('limit', default=1000, type=int)
        
        # Get raw data
        cash_flow_data = fetch_company_cash_flow_data(year=year, limit=limit)
        
        if not cash_flow_data:
            return jsonify({
                'success': False,
                'error': 'No training data found'
            }), 404
        
        # Convert to DataFrame for easier processing
        df = pd.DataFrame(cash_flow_data)
        
        # Filter by industry if specified
        if industry:
            df = df[df['industry'].str.lower() == industry.lower()]
        
        # Feature columns (key financial metrics from your table)
        feature_columns = [
            'net_income', 'net_cash_from_operating_activities', 'changes_in_working_capital',
            'accounts_receivable', 'inventory', 'accounts_payable',
            'capital_expenditures', 'net_cash_from_financing_activities', 'net_cash_from_investing_activities',
            'depreciation_and_amortization', 'stock_based_compensation', 'acquisitions',
            'dividends_paid', 'share_repurchases', 'free_cash_flow', 'ocf_to_net_income_ratio',
            'debt_to_equity_ratio', 'interest_coverage_ratio'
        ]
        
        # Target column
        target_column = 'liquidation_label'
        
        # Clean data and handle missing values
        X = df[feature_columns].fillna(0)  # Fill NaN with 0 for financial data
        y = df[target_column].fillna(0)
        
        # Additional metadata
        metadata = df[['company_name', 'year', 'industry']].to_dict('records')
        
        return jsonify({
            'success': True,
            'records_count': len(df),
            'feature_columns': feature_columns,
            'target_column': target_column,
            'X_data': X.values.tolist(),
            'y_data': y.values.tolist(),
            'feature_names': feature_columns,
            'metadata': metadata,
            'data_summary': {
                'companies': df['company_name'].nunique(),
                'years': sorted(df['year'].unique().tolist()),
                'industries': df['industry'].unique().tolist(),
                'liquidation_risk_distribution': df[target_column].value_counts().to_dict()
            }
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc()
        }), 500

# ===========================================
# ML MODEL ENDPOINTS (keeping your existing ones)
# ===========================================

@app.route('/api/models/create', methods=['POST'])
def create_model():
    """Create a new ML model"""
    try:
        data = request.json
        model_type = data.get('model_type')  # 'xgboost', 'random_forest', 'neural_networks', 'lightgbm'
        algorithm = data.get('algorithm')    # 'regressor', 'classifier'
        scenario = data.get('scenario', 'financial_health')
        model_name = data.get('model_name', f"{model_type}_{algorithm}_{scenario}")
        
        if not model_type or not algorithm:
            return jsonify({'error': 'model_type and algorithm are required'}), 400
        
        # Create model based on type
        model = None
        config = {}
        
        if model_type == 'xgboost' and XGBOOST_AVAILABLE:
            config = XGBConfig.get_config_by_scenario(scenario)
            if algorithm == 'regressor':
                model = XGBRegressorModel(**config)
            elif algorithm == 'classifier':
                model = XGBClassifierModel(**config)
                
        elif model_type == 'random_forest' and RANDOM_FOREST_AVAILABLE:
            config = RandomForestConfig.get_config_by_scenario(scenario)
            if algorithm == 'regressor':
                model = RandomForestRegressorModel(**config)
            elif algorithm == 'classifier':
                model = RandomForestClassifierModel(**config)
                
        elif model_type == 'neural_networks' and NEURAL_NETWORKS_AVAILABLE:
            config = NeuralNetworkConfig.get_config_by_scenario(scenario)
            if algorithm == 'regressor':
                model = NeuralNetworkRegressor(**config)
            elif algorithm == 'classifier':
                model = NeuralNetworkClassifier(**config)
                
        elif model_type == 'lightgbm' and LIGHTGBM_AVAILABLE:
            config = LGBConfig.get_config_by_scenario(scenario)
            if algorithm == 'regressor':
                model = LGBRegressorModel(**config)
            elif algorithm == 'classifier':
                model = LGBClassifierModel(**config)
        
        if model is None:
            return jsonify({'error': f'Cannot create {model_type} {algorithm} - not available'}), 400
        
        # Store model
        models[model_name] = {
            'model': model,
            'type': model_type,
            'algorithm': algorithm,
            'scenario': scenario,
            'config': config,
            'created_at': datetime.now().isoformat(),
            'is_trained': False
        }
        
        # Register with performance tracker
        if performance_tracker:
            performance_tracker.register_model(model_name, {
                'model_type': f"{model_type}_{algorithm}",
                'scenario': scenario
            })
        
        return jsonify({
            'message': f'Model {model_name} created successfully',
            'model_name': model_name,
            'model_type': model_type,
            'algorithm': algorithm,
            'scenario': scenario,
            'config': config
        })
        
    except Exception as e:
        return jsonify({'error': str(e), 'traceback': traceback.format_exc()}), 500

@app.route('/api/models/train-from-db', methods=['POST'])
def train_model_from_database():
    """Train a model using data directly from the database - FIXED"""
    try:
        data = request.json
        model_name = data.get('model_name')
        industry_filter = data.get('industry')
        year_filter = data.get('year', type=int)
        test_split = data.get('test_split', 0.2)
        validation_split = data.get('validation_split', 0.1)
        
        if model_name not in models:
            return jsonify({'error': f'Model {model_name} not found'}), 404
        
        if not db_connection:
            return jsonify({'error': 'Database not connected'}), 500
        
        # Fetch training data from database
        cash_flow_data = fetch_company_cash_flow_data(limit=1000)
        
        if not cash_flow_data:
            return jsonify({'error': 'No training data found in database'}), 500
        
        # Convert to DataFrame
        df = pd.DataFrame(cash_flow_data)
        
        # Filter by industry if specified
        if industry_filter:
            df = df[df['industry'].str.lower() == industry_filter.lower()]
        
        # Filter by year if specified
        if year_filter:
            df = df[df['year'] == year_filter]
        
        if len(df) == 0:
            return jsonify({'error': 'No data found matching the specified filters'}), 404
        
        # Feature columns
        feature_columns = [
            'net_income', 'net_cash_from_operating_activities', 'changes_in_working_capital',
            'accounts_receivable', 'inventory', 'accounts_payable',
            'capital_expenditures', 'net_cash_from_financing_activities', 'net_cash_from_investing_activities',
            'depreciation_and_amortization', 'stock_based_compensation', 'acquisitions',
            'dividends_paid', 'share_repurchases', 'free_cash_flow', 'ocf_to_net_income_ratio',
            'debt_to_equity_ratio', 'interest_coverage_ratio'
        ]
        
        # Prepare data
        X = df[feature_columns].fillna(0).values
        y = df['liquidation_label'].fillna(0).values
        
        # Split data
        from sklearn.model_selection import train_test_split
        
        # First split: separate test set
        X_temp, X_test, y_temp, y_test = train_test_split(
            X, y, test_size=test_split, random_state=42, stratify=y
        )
        
        # Second split: separate train and validation
        if validation_split > 0:
            X_train, X_val, y_train, y_val = train_test_split(
                X_temp, y_temp, test_size=validation_split/(1-test_split), 
                random_state=42, stratify=y_temp
            )
        else:
            X_train, y_train = X_temp, y_temp
            X_val, y_val = None, None
        
        # Convert to DataFrames
        X_train = pd.DataFrame(X_train, columns=feature_columns)
        if X_val is not None:
            X_val = pd.DataFrame(X_val, columns=feature_columns)
        X_test = pd.DataFrame(X_test, columns=feature_columns)
        
        # Train model
        model_info = models[model_name]
        model = model_info['model']
        
        if model_info['algorithm'] == 'classifier':
            class_names = ['No Risk', 'Liquidation Risk']
            if X_val is not None:
                success = model.train(X_train, y_train, X_val, y_val, 
                                    class_names=class_names, verbose=True)
            else:
                success = model.train(X_train, y_train, class_names=class_names, verbose=True)
        else:  # regressor
            if X_val is not None:
                success = model.train(X_train, y_train, X_val, y_val, verbose=True)
            else:
                success = model.train(X_train, y_train, verbose=True)
        
        if success:
            models[model_name]['is_trained'] = True
            models[model_name]['trained_at'] = datetime.now().isoformat()
            
            # Evaluate on test set
            test_metrics = model.evaluate(X_test, y_test)
            
            return jsonify({
                'message': f'Model {model_name} trained successfully from database',
                'model_name': model_name,
                'is_trained': True,
                'data_summary': {
                    'total_samples': len(X),
                    'training_samples': len(X_train),
                    'validation_samples': len(X_val) if X_val is not None else 0,
                    'test_samples': len(X_test),
                    'features': len(feature_columns)
                },
                'test_metrics': test_metrics,
                'data_source': 'PostgreSQL Database (cash_flow_statement table)'
            })
        else:
            return jsonify({'error': f'Training failed for model {model_name}'}), 500
            
    except Exception as e:
        return jsonify({'error': str(e), 'traceback': traceback.format_exc()}), 500

@app.route('/api/models/predict-company', methods=['POST'])
def predict_company_risk():
    """Predict financial risk for a specific company using database data - FIXED"""
    try:
        data = request.json
        model_name = data.get('model_name')
        company_identifier = data.get('company_identifier')  # company_id or company_name
        year = data.get('year')
        
        if model_name not in models:
            return jsonify({'error': f'Model {model_name} not found'}), 404
        
        model_info = models[model_name]
        if not model_info['is_trained']:
            return jsonify({'error': f'Model {model_name} is not trained'}), 400
        
        if not db_connection:
            return jsonify({'error': 'Database not connected'}), 500
        
        # Fetch company data
        if str(company_identifier).isdigit():
            company_data = fetch_company_cash_flow_data(
                company_id=int(company_identifier), year=year, limit=1
            )
        else:
            company_data = fetch_company_cash_flow_data(
                company_name=company_identifier, year=year, limit=1
            )
        
        if not company_data:
            return jsonify({
                'error': f'No data found for company "{company_identifier}" for year {year}'
            }), 404
        
        # Prepare feature data
        record = company_data[0]
        feature_columns = [
            'net_income', 'net_cash_from_operating_activities', 'changes_in_working_capital',
            'accounts_receivable', 'inventory', 'accounts_payable',
            'capital_expenditures', 'net_cash_from_financing_activities', 'net_cash_from_investing_activities',
            'depreciation_and_amortization', 'stock_based_compensation', 'acquisitions',
            'dividends_paid', 'share_repurchases', 'free_cash_flow', 'ocf_to_net_income_ratio',
            'debt_to_equity_ratio', 'interest_coverage_ratio'
        ]
        
        # Extract features
        X_pred = []
        for col in feature_columns:
            value = record.get(col, 0)
            X_pred.append(value if value is not None else 0)
        
        X_pred = np.array([X_pred])
        X_pred_df = pd.DataFrame(X_pred, columns=feature_columns)
        
        # Make prediction
        model = model_info['model']
        predictions = model.predict(X_pred_df)
        
        result = {
            'company_info': {
                'company_id': record.get('company_id'),
                'company_name': record.get('company_name'),
                'industry': record.get('industry'),
                'year': record.get('year')
            },
            'prediction': {
                'risk_score': float(predictions[0]),
                'risk_level': 'High' if predictions[0] > 0.5 else 'Low',
                'model_used': model_name
            },
            'input_features': dict(zip(feature_columns, X_pred[0]))
        }
        
        # Add probabilities for classifier
        if model_info['algorithm'] == 'classifier':
            try:
                probabilities = model.predict_proba(X_pred_df)
                result['prediction'].update({
                    'probability_no_risk': float(probabilities[0][0]),
                    'probability_liquidation_risk': float(probabilities[0][1]),
                    'confidence': float(np.max(probabilities[0]))
                })
            except Exception as e:
                print(f"⚠️ Probability calculation failed: {e}")
        
        return jsonify({
            'success': True,
            'result': result,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc()
        }), 500

@app.route('/api/models/predict', methods=['POST'])
def predict():
    """Enhanced predict endpoint with basic confidence"""
    try:
        data = request.json
        model_name = data.get('model_name')
        include_confidence = data.get('include_confidence', True)
        
        if model_name not in models:
            return jsonify({'error': f'Model {model_name} not found'}), 404
        
        model_info = models[model_name]
        
        if not model_info['is_trained']:
            return jsonify({'error': f'Model {model_name} is not trained'}), 400
        
        # Get prediction data
        X_pred = np.array(data.get('X_pred'))
        feature_names = data.get('feature_names')
        
        # Convert to DataFrame if feature names provided
        if feature_names:
            X_pred = pd.DataFrame(X_pred, columns=feature_names)
        
        model = model_info['model']
        
        # Make predictions
        predictions = model.predict(X_pred)
        result = {
            'model_name': model_name,
            'predictions': predictions.tolist(),
            'n_samples': len(predictions)
        }
        
        # Add confidence/probability information
        if include_confidence:
            if model_info['algorithm'] == 'classifier':
                try:
                    probabilities = model.predict_proba(X_pred)
                    confidence_scores = np.max(probabilities, axis=1)
                    
                    result.update({
                        'probabilities': probabilities.tolist(),
                        'confidence_scores': confidence_scores.tolist(),
                        'mean_confidence': float(np.mean(confidence_scores)),
                        'min_confidence': float(np.min(confidence_scores)),
                        'max_confidence': float(np.max(confidence_scores))
                    })
                    
                except Exception as prob_error:
                    print(f"⚠️ Probability prediction failed: {prob_error}")
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e), 'traceback': traceback.format_exc()}), 500

@app.route('/api/models/predict_with_confidence', methods=['POST'])
def predict_with_confidence():
    """Make predictions with detailed confidence analysis"""
    try:
        if not CONFIDENCE_UTILS_AVAILABLE or not ml_predictor:
            return jsonify({'error': 'Confidence utilities not available'}), 400
        
        data = request.json
        model_name = data.get('model_name')
        
        if model_name not in models:
            return jsonify({'error': f'Model {model_name} not found'}), 404
        
        model_info = models[model_name]
        
        if not model_info['is_trained']:
            return jsonify({'error': f'Model {model_name} is not trained'}), 400
        
        # Get prediction data
        X_pred = np.array(data.get('X_pred'))
        feature_names = data.get('feature_names')
        confidence_threshold = data.get('confidence_threshold', 0.7)
        include_details = data.get('include_details', True)
        
        # Convert to DataFrame if feature names provided
        if feature_names:
            X_pred = pd.DataFrame(X_pred, columns=feature_names)
        
        model = model_info['model']
        
        # Enhanced model info for confidence analysis
        enhanced_model_info = {
            'name': model_name,
            'type': model_info['type'],
            'algorithm': model_info['algorithm'],
            'scenario': model_info.get('scenario', 'unknown'),
            'created_at': model_info.get('created_at'),
            'trained_at': model_info.get('trained_at')
        }
        
        # Get predictions with confidence
        result = ml_predictor.predict_with_confidence(
            model, enhanced_model_info, X_pred, confidence_threshold
        )
        
        # Format response
        formatted_result = format_confidence_response(result, include_details)
        
        # Add recommendations
        if 'confidence_summary' in result:
            formatted_result['recommendations'] = get_confidence_recommendations(
                result['confidence_summary']
            )
        
        # Add timestamp
        formatted_result['timestamp'] = datetime.now().isoformat()
        
        return jsonify(formatted_result)
        
    except Exception as e:
        return jsonify({
            'error': str(e), 
            'traceback': traceback.format_exc()
        }), 500

@app.route('/api/models')
def list_models():
    """List all created models"""
    model_list = []
    for name, info in models.items():
        model_list.append({
            'name': name,
            'type': info['type'],
            'algorithm': info['algorithm'],
            'scenario': info['scenario'],
            'is_trained': info['is_trained'],
            'created_at': info['created_at'],
            'trained_at': info.get('trained_at')
        })
    
    return jsonify({
        'models': model_list,
        'total_models': len(model_list)
    })

@app.route('/api/models/<model_name>')
def get_model_info(model_name):
    """Get detailed information about a specific model"""
    try:
        if model_name not in models:
            return jsonify({'error': f'Model {model_name} not found'}), 404
        
        model_info = models[model_name].copy()
        model = model_info.pop('model')  # Remove model object from response
        
        # Add model summary if available
        if hasattr(model, 'get_model_summary'):
            model_info['summary'] = model.get_model_summary()
        
        return jsonify(model_info)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/models/<model_name>/delete', methods=['DELETE'])
def delete_model(model_name):
    """Delete a specific model"""
    try:
        if model_name not in models:
            return jsonify({'error': f'Model {model_name} not found'}), 404
        
        # Remove from models dict
        del models[model_name]
        
        # Remove from performance tracker if available
        if performance_tracker:
            try:
                performance_tracker.remove_model(model_name)
            except:
                pass
        
        return jsonify({
            'message': f'Model {model_name} deleted successfully'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ===========================================
# DASHBOARD AND ANALYTICS ENDPOINTS (FIXED)
# ===========================================

@app.route('/api/dashboard/summary')
def get_dashboard_summary():
    """Get dashboard summary statistics - FIXED"""
    try:
        if not db_connection:
            return jsonify({'error': 'Database not available'}), 500
        
        # Get overall statistics from cash_flow_statement table
        summary_query = """
        SELECT 
            COUNT(*) as total_records,
            COUNT(DISTINCT company_name) as total_companies,
            COUNT(DISTINCT industry) as total_industries,
            MIN(year) as earliest_year,
            MAX(year) as latest_year,
            AVG(liquidation_label) as overall_liquidation_rate,
            AVG(net_income) as avg_net_income,
            AVG(free_cash_flow) as avg_free_cash_flow
        FROM cash_flow_statement
        """
        
        summary_result = db_connection.execute_select(summary_query)
        summary = summary_result[0] if summary_result else {}
        
        # Get industry breakdown
        industry_query = """
        SELECT 
            industry,
            COUNT(DISTINCT company_name) as companies,
            AVG(liquidation_label) as liquidation_rate,
            AVG(net_income) as avg_net_income
        FROM cash_flow_statement
        WHERE industry IS NOT NULL
        GROUP BY industry
        ORDER BY companies DESC
        """
        
        industries = db_connection.execute_select(industry_query)
        
        # Get yearly trends
        yearly_query = """
        SELECT 
            year,
            COUNT(DISTINCT company_name) as companies,
            AVG(net_income) as avg_net_income,
            AVG(free_cash_flow) as avg_free_cash_flow,
            AVG(liquidation_label) as liquidation_rate
        FROM cash_flow_statement
        GROUP BY year
        ORDER BY year
        """
        
        yearly_trends = db_connection.execute_select(yearly_query)
        
        return jsonify({
            'success': True,
            'summary': summary,
            'industries': industries if industries else [],
            'yearly_trends': yearly_trends if yearly_trends else [],
            'models_status': {
                'total_models': len(models),
                'trained_models': sum(1 for m in models.values() if m['is_trained']),
                'available_algorithms': {
                    'xgboost': XGBOOST_AVAILABLE,
                    'random_forest': RANDOM_FOREST_AVAILABLE,
                    'neural_networks': NEURAL_NETWORKS_AVAILABLE,
                    'lightgbm': LIGHTGBM_AVAILABLE
                }
            },
            'database_status': {
                'connected': db_connection is not None,
                'total_cash_flow_records': summary.get('total_records', 0)
            },
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/analytics/risk-distribution')
def get_risk_distribution():
    """Get risk distribution analytics - FIXED"""
    try:
        if not db_connection:
            return jsonify({'error': 'Database not available'}), 500
        
        # Risk distribution by industry
        industry_risk_query = """
        SELECT 
            industry,
            SUM(CASE WHEN liquidation_label = 1 THEN 1 ELSE 0 END) as high_risk_companies,
            SUM(CASE WHEN liquidation_label = 0 THEN 1 ELSE 0 END) as low_risk_companies,
            COUNT(*) as total_records,
            AVG(liquidation_label) as risk_rate
        FROM cash_flow_statement
        WHERE industry IS NOT NULL
        GROUP BY industry
        ORDER BY risk_rate DESC
        """
        
        industry_risk = db_connection.execute_select(industry_risk_query)
        
        # Risk distribution by year
        yearly_risk_query = """
        SELECT 
            year,
            SUM(CASE WHEN liquidation_label = 1 THEN 1 ELSE 0 END) as high_risk_companies,
            SUM(CASE WHEN liquidation_label = 0 THEN 1 ELSE 0 END) as low_risk_companies,
            COUNT(*) as total_records,
            AVG(liquidation_label) as risk_rate
        FROM cash_flow_statement
        GROUP BY year
        ORDER BY year
        """
        
        yearly_risk = db_connection.execute_select(yearly_risk_query)
        
        return jsonify({
            'success': True,
            'industry_risk_distribution': industry_risk if industry_risk else [],
            'yearly_risk_trends': yearly_risk if yearly_risk else [],
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# ===========================================
# WEB ROUTES (keeping your existing ones)
# ===========================================

@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('index.html', 
                         xgboost_available=XGBOOST_AVAILABLE,
                         random_forest_available=RANDOM_FOREST_AVAILABLE,
                         neural_networks_available=NEURAL_NETWORKS_AVAILABLE,
                         lightgbm_available=LIGHTGBM_AVAILABLE,
                         ensemble_available=ENSEMBLE_AVAILABLE,
                         confidence_available=CONFIDENCE_UTILS_AVAILABLE,
                         database_available=db_connection is not None)

@app.route('/analytics/confidence')
def confidence_dashboard():
    """Confidence analysis dashboard"""
    try:
        return render_template('analytics/confidence_dashboard.html')
    except Exception as e:
        return f"Dashboard not available: {e}", 404

@app.route('/api/status')
def api_status():
    """API status and available models - FIXED"""
    db_stats = {}
    if db_connection:
        try:
            # Get database statistics
            stats_query = "SELECT COUNT(*) as total_records FROM cash_flow_statement"
            stats_result = db_connection.execute_select(stats_query)
            if stats_result:
                db_stats['total_cash_flow_records'] = stats_result[0]['total_records']
        except Exception as e:
            db_stats['error'] = str(e)
    
    return jsonify({
        'status': 'active',
        'timestamp': datetime.now().isoformat(),
        'database_connected': db_connection is not None,
        'database_stats': db_stats,
        'available_models': {
            'xgboost': XGBOOST_AVAILABLE,
            'random_forest': RANDOM_FOREST_AVAILABLE,
            'neural_networks': NEURAL_NETWORKS_AVAILABLE,
            'lightgbm': LIGHTGBM_AVAILABLE,
            'ensemble': ENSEMBLE_AVAILABLE,
            'evaluation': EVALUATION_AVAILABLE,
            'confidence_utils': CONFIDENCE_UTILS_AVAILABLE
        },
        'active_models': list(models.keys()),
        'database_classes_available': DATABASE_CLASSES_AVAILABLE
    })

@app.route('/companies')
def companies_page():
    """Companies overview/search page"""
    return render_template('companies.html')

@app.route('/analytics/radar')
def radar_chart():
    """Radar chart analysis page"""
    return render_template('analytics/radar_chart.html')

@app.route('/analytics/trend')
def trend_analysis():
    return render_template('analytics/trend_analysis.html')

@app.route('/risk')
def risk_assessment():
    """Risk Assessment overview page"""
    return render_template('risk_assessment.html')

@app.route('/upload', methods=['GET','POST'])
def upload_file():
    return render_template('upload.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

# ===========================================
# ERROR HANDLERS
# ===========================================

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

@app.errorhandler(Exception)
def handle_exception(e):
    """Handle unexpected exceptions"""
    return jsonify({
        'error': 'An unexpected error occurred',
        'message': str(e),
        'type': type(e).__name__
    }), 500

# ===========================================
# APPLICATION STARTUP (FIXED)
# ===========================================

if __name__ == '__main__':
    print("🚀 Starting Financial Risk Assessment Application...")
    print("="*60)
    print(f"✅ XGBoost Available: {XGBOOST_AVAILABLE}")
    print(f"✅ Random Forest Available: {RANDOM_FOREST_AVAILABLE}")
    print(f"✅ Neural Networks Available: {NEURAL_NETWORKS_AVAILABLE}")
    print(f"✅ LightGBM Available: {LIGHTGBM_AVAILABLE}")
    print(f"✅ Ensemble Available: {ENSEMBLE_AVAILABLE}")
    print(f"✅ Evaluation Available: {EVALUATION_AVAILABLE}")
    print(f"✅ Confidence Utils Available: {CONFIDENCE_UTILS_AVAILABLE}")
    print(f"✅ Database Classes Available: {DATABASE_CLASSES_AVAILABLE}")
    print("="*60)
    
    # Initialize components
    db_initialized = initialize_components()
    
    # Print database status
    if db_connection and db_initialized:
        print("✅ PostgreSQL Database Connected")
        try:
            # Test database with sample query
            test_result = db_connection.execute_select(
                "SELECT COUNT(*) as total_records FROM cash_flow_statement"
            )
            if test_result:
                print(f"📊 Total Cash Flow Records: {test_result[0]['total_records']}")
                
            # Get companies count
            companies_result = db_connection.execute_select(
                "SELECT COUNT(DISTINCT company_name) as total_companies FROM cash_flow_statement"
            )
            if companies_result:
                print(f"🏢 Total Companies: {companies_result[0]['total_companies']}")
                
            # Get industries count
            industries_result = db_connection.execute_select(
                "SELECT COUNT(DISTINCT industry) as total_industries FROM cash_flow_statement WHERE industry IS NOT NULL"
            )
            if industries_result:
                print(f"🏭 Total Industries: {industries_result[0]['total_industries']}")
                
        except Exception as e:
            print(f"⚠️ Database test query failed: {e}")
    else:
        print("❌ PostgreSQL Database Not Connected")
        if not DATABASE_CLASSES_AVAILABLE:
            print("❌ Database classes not available - check imports")
    
    print("="*60)
    
    # Start Flask app
    print("\n🌐 Starting Flask server...")
    print("📊 Main Dashboard: http://localhost:5000")
    print("🎯 Confidence Dashboard: http://localhost:5000/analytics/confidence")
    print("🔗 API Status: http://localhost:5000/api/status")
    print("📋 Models: http://localhost:5000/api/models")
    print("\n💰 Cash Flow Data Endpoints:")
    print("📊 Companies Data: GET /api/cash-flow/companies")
    print("🔍 Search Companies: GET /api/cash-flow/search?q=<term>")
    print("🏢 Company Profile: GET /api/cash-flow/company/<id_or_name>")
    print("📈 Training Data: GET /api/cash-flow/train-data")
    print("🏭 Industries: GET /api/cash-flow/industries")
    print("🏢 All Companies: GET /api/companies/all")
    print("\n🤖 ML Model Endpoints:")
    print("🔧 Create Model: POST /api/models/create")
    print("🎓 Train from DB: POST /api/models/train-from-db")
    print("🔮 Predict Company Risk: POST /api/models/predict-company")
    print("📊 Confidence Analysis: POST /api/models/predict_with_confidence")
    print("\n📊 Analytics Endpoints:")
    print("📈 Dashboard Summary: GET /api/dashboard/summary")
    print("⚠️ Risk Distribution: GET /api/analytics/risk-distribution")
    print("="*60)
    
    app.run(debug=True, host='0.0.0.0', port=5000)