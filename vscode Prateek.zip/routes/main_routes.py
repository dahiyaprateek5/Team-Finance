from flask import Blueprint, render_template, redirect, url_for, flash # type: ignore
from utils.helpers import calculate_cash_flow_health_score, format_currency # type: ignore
from config.database import db_conn

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def home():
    """Main landing page"""
    return render_template('index.html')

@main_bp.route('/dashboard')
def dashboard():
    """Simple dashboard using cash_flow_statement table"""
    try:
        # Get basic stats
        stats_query = """
        SELECT 
            COUNT(DISTINCT company_name) as total_companies,
            COUNT(*) as total_records,
            AVG(CASE WHEN net_income > 0 THEN 1 ELSE 0 END) * 100 as profitable_percentage,
            SUM(CASE WHEN liquidation_label = 1 THEN 1 ELSE 0 END) as high_risk_companies
        FROM cash_flow_statement
        """
        
        stats_result = db_conn.execute_query(stats_query)
        stats = stats_result[0] if stats_result else {
            'total_companies': 0,
            'total_records': 0,
            'profitable_percentage': 0,
            'high_risk_companies': 0
        }
        
        # Get recent companies
        recent_companies_query = """
        SELECT company_name, industry, net_income, 
               net_cash_from_operating_activities, liquidation_label, year, free_cash_flow
        FROM cash_flow_statement 
        ORDER BY year DESC, company_name
        LIMIT 10
        """
        
        recent_companies = db_conn.execute_query(recent_companies_query)
        
        # Process companies data
        processed_companies = []
        if recent_companies:
            for company in recent_companies:
                health_score = calculate_cash_flow_health_score(company)
                processed_company = {
                    'company_name': company.get('company_name', 'Unknown'),
                    'industry': company.get('industry', 'General'),
                    'net_income': format_currency(company.get('net_income')),
                    'operating_cash_flow': format_currency(company.get('net_cash_from_operating_activities')),
                    'free_cash_flow': format_currency(company.get('free_cash_flow')),
                    'health_score': health_score,
                    'risk_level': 'Low' if health_score >= 75 else 'Medium' if health_score >= 50 else 'High',
                    'liquidation_risk': company.get('liquidation_label', 0),
                    'year': company.get('year', 'N/A')
                }
                processed_companies.append(processed_company)
        
        return render_template('dashboard.html', 
                             stats=stats, 
                             recent_companies=processed_companies)
                             
    except Exception as e:
        flash(f'Dashboard error: {str(e)}', 'error')
        return redirect(url_for('main.home'))

@main_bp.route('/companies')
def companies_page():
    """Render the companies management page"""
    return render_template('companies.html')

@main_bp.route('/analysis')
def analysis_page():
    """Financial Analysis Page"""
    return render_template('analysis.html')