from .main_routes import main_bp
from .api_routes import api_bp
from .analytics_routes import analytics_bp
from .ai_routes import ai_bp
from .upload_routes import upload_bp  # type: ignore

__all__ = ['main_bp', 'api_bp', 'analytics_bp', 'ai_bp', 'upload_bp']