from abc import ABC, abstractmethod
import numpy as np # type: ignore
from typing import Dict, List, Any, Tuple
from datetime import datetime

class BaseMLModel(ABC):
    """Base class for all ML models"""
    
    def __init__(self, model_name: str):
        self.model_name = model_name
        self.model = None
        self.is_trained = False
        self.training_time = 0
        self.performance_metrics = {}
        self.feature_importance = None
        
    @abstractmethod
    def create_model(self, **kwargs):
        """Create the ML model with given parameters"""
        pass
    
    @abstractmethod
    def train(self, X_train: np.ndarray, y_train: np.ndarray, X_val: np.ndarray = None, y_val: np.ndarray = None):
        """Train the model"""
        pass
    
    @abstractmethod
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Make predictions"""
        pass
    
    @abstractmethod
    def evaluate(self, X_test: np.ndarray, y_test: np.ndarray) -> Dict:
        """Evaluate model performance"""
        pass
    
    def get_feature_importance(self) -> np.ndarray:
        """Get feature importance if available"""
        return self.feature_importance
    
    def get_model_info(self) -> Dict:
        """Get model information"""
        return {
            'model_name': self.model_name,
            'is_trained': self.is_trained,
            'training_time': self.training_time,
            'performance_metrics': self.performance_metrics
        }