"""
ML Algorithms Package Initialization - FIXED VERSION
Handles import and availability of all ML models with proper error handling
"""

import sys
import os
import warnings
warnings.filterwarnings('ignore')

# Add project root to path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

print("🤖 Initializing ML Algorithms Package...")

# Try to import base model
try:
    from .base_model import BaseModel
    print("✅ Base model class loaded")
except ImportError as e:
    print(f"⚠️ Base model not available: {e}")
    BaseModel = None

# Initialize availability flags
XGBOOST_AVAILABLE = False
RANDOM_FOREST_AVAILABLE = False
NEURAL_NETWORKS_AVAILABLE = False
LIGHTGBM_AVAILABLE = False
ENSEMBLE_AVAILABLE = False
EVALUATION_AVAILABLE = False

# Try XGBoost imports
try:
    from .xgboost import XGBRegressorModel, XGBClassifierModel, XGBConfig # type: ignore
    XGBOOST_AVAILABLE = True
    print("✅ XGBoost models loaded")
except ImportError as e:
    print(f"⚠️ XGBoost models not available: {e}")
    XGBRegressorModel = None
    XGBClassifierModel = None
    XGBConfig = None

# Try Random Forest imports
try:
    from .random_forest import RandomForestRegressorModel, RandomForestClassifierModel, RandomForestConfig
    RANDOM_FOREST_AVAILABLE = True
    print("✅ Random Forest models loaded")
except ImportError as e:
    print(f"⚠️ Random Forest models not available: {e}")
    RandomForestRegressorModel = None
    RandomForestClassifierModel = None
    RandomForestConfig = None

# Try Neural Networks imports
try:
    from .neural_networks import NeuralNetworkRegressor, NeuralNetworkClassifier, NeuralNetworkConfig
    NEURAL_NETWORKS_AVAILABLE = True
    print("✅ Neural Networks models loaded")
except ImportError as e:
    print(f"⚠️ Neural Networks models not available: {e}")
    NeuralNetworkRegressor = None
    NeuralNetworkClassifier = None
    NeuralNetworkConfig = None

# Try LightGBM imports
try:
    from .lightgbm import LGBRegressorModel, LGBClassifierModel, LGBConfig
    LIGHTGBM_AVAILABLE = True
    print("✅ LightGBM models loaded")
except ImportError as e:
    print(f"⚠️ LightGBM models not available: {e}")
    LGBRegressorModel = None
    LGBClassifierModel = None
    LGBConfig = None

# Try Ensemble Manager import
try:
    from .ensemble_manager import EnsembleManager # type: ignore
    ENSEMBLE_AVAILABLE = True
    print("✅ Ensemble Manager loaded")
except ImportError as e:
    print(f"⚠️ Ensemble Manager not available: {e}")
    EnsembleManager = None

# Try Model Evaluation imports
try:
    from .model_evaluation import RegressionMetrics, ClassificationMetrics, CrossValidator, PerformanceTracker
    EVALUATION_AVAILABLE = True
    print("✅ Model Evaluation loaded")
except ImportError as e:
    print(f"⚠️ Model Evaluation not available: {e}")
    RegressionMetrics = None
    ClassificationMetrics = None
    CrossValidator = None
    PerformanceTracker = None

# Package exports
__all__ = [
    'BaseModel',
    'XGBRegressorModel', 'XGBClassifierModel', 'XGBConfig',
    'RandomForestRegressorModel', 'RandomForestClassifierModel', 'RandomForestConfig',
    'NeuralNetworkRegressor', 'NeuralNetworkClassifier', 'NeuralNetworkConfig',
    'LGBRegressorModel', 'LGBClassifierModel', 'LGBConfig',
    'EnsembleManager',
    'RegressionMetrics', 'ClassificationMetrics', 'CrossValidator', 'PerformanceTracker',
    'XGBOOST_AVAILABLE', 'RANDOM_FOREST_AVAILABLE', 'NEURAL_NETWORKS_AVAILABLE',
    'LIGHTGBM_AVAILABLE', 'ENSEMBLE_AVAILABLE', 'EVALUATION_AVAILABLE'
]

# Package metadata
__version__ = "1.0.0"
__author__ = "Financial ML Team"

def get_available_models():
    """Get list of available model types"""
    available = []
    if XGBOOST_AVAILABLE:
        available.append('xgboost')
    if RANDOM_FOREST_AVAILABLE:
        available.append('random_forest')
    if NEURAL_NETWORKS_AVAILABLE:
        available.append('neural_networks')
    if LIGHTGBM_AVAILABLE:
        available.append('lightgbm')
    return available

def get_package_status():
    """Get complete package status"""
    return {
        'xgboost': XGBOOST_AVAILABLE,
        'random_forest': RANDOM_FOREST_AVAILABLE,
        'neural_networks': NEURAL_NETWORKS_AVAILABLE,
        'lightgbm': LIGHTGBM_AVAILABLE,
        'ensemble': ENSEMBLE_AVAILABLE,
        'evaluation': EVALUATION_AVAILABLE,
        'available_models': get_available_models()
    }

print("="*60)
print("📊 ML Algorithms Package Status:")
print(f"✅ XGBoost: {XGBOOST_AVAILABLE}")
print(f"✅ Random Forest: {RANDOM_FOREST_AVAILABLE}")
print(f"✅ Neural Networks: {NEURAL_NETWORKS_AVAILABLE}")
print(f"✅ LightGBM: {LIGHTGBM_AVAILABLE}")
print(f"✅ Ensemble: {ENSEMBLE_AVAILABLE}")
print(f"✅ Evaluation: {EVALUATION_AVAILABLE}")
print("="*60)