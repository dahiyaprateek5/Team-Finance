# =====================================
# File: ml_algorithms/neural_networks/nn_regressor_lite.py
# Lightweight Neural Network Regressor using only NumPy
# =====================================

"""
Lightweight Neural Network Regressor for Financial Analysis
Simple implementation using only NumPy - no TensorFlow required
"""

import numpy as np  
import pandas as pd  
from typing import Dict, List, Any, Optional, Tuple, Union
import json
from datetime import datetime
import pickle
import warnings
warnings.filterwarnings('ignore')

# Try to import sklearn for metrics
try:
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split  
    from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score  
    SKLEARN_AVAILABLE = True  
except ImportError:
    SKLEARN_AVAILABLE = False
    print("⚠️ Scikit-learn not available. Using manual implementations.")

class SimpleNeuralNetwork:
    """
    Simple Neural Network implementation using only NumPy
    Suitable for financial regression tasks
    """
    
    def __init__(self, hidden_layers: List[int] = None, 
                 learning_rate: float = 0.001,
                 epochs: int = 100,
                 random_state: int = 42):
        """
        Initialize Simple Neural Network
        
        Args:
            hidden_layers: List of hidden layer sizes
            learning_rate: Learning rate for training
            epochs: Number of training epochs
            random_state: Random seed
        """
        
        if hidden_layers is None:
            hidden_layers = [64, 32]
            
        self.hidden_layers = hidden_layers
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.random_state = random_state
        
        # Set random seed
        np.random.seed(random_state)
        
        # Model components
        self.weights = []
        self.biases = []
        self.is_trained = False
        self.feature_names = None
        self.n_features = None
        self.scaler_mean = None
        self.scaler_std = None
        self.training_losses = []
        
        print(f"🧠 Simple Neural Network initialized with {len(hidden_layers)} hidden layers")
    
    def _sigmoid(self, x):
        """Sigmoid activation function"""
        return 1 / (1 + np.exp(-np.clip(x, -500, 500)))
    
    def _sigmoid_derivative(self, x):
        """Derivative of sigmoid function"""
        sig = self._sigmoid(x)
        return sig * (1 - sig)
    
    def _relu(self, x):
        """ReLU activation function"""
        return np.maximum(0, x)
    
    def _relu_derivative(self, x):
        """Derivative of ReLU function"""
        return (x > 0).astype(float)
    
    def _standardize(self, X, fit=False):
        """Standardize features"""
        if fit:
            self.scaler_mean = np.mean(X, axis=0)
            self.scaler_std = np.std(X, axis=0)
            self.scaler_std = np.where(self.scaler_std == 0, 1, self.scaler_std)
        
        return (X - self.scaler_mean) / self.scaler_std
    
    def _init_weights(self, input_size):
        """Initialize weights and biases"""
        self.weights = []
        self.biases = []
        
        layer_sizes = [input_size] + self.hidden_layers + [1]
        
        for i in range(len(layer_sizes) - 1):
            # Xavier initialization
            limit = np.sqrt(6 / (layer_sizes[i] + layer_sizes[i + 1]))
            weight = np.random.uniform(-limit, limit, (layer_sizes[i], layer_sizes[i + 1]))
            bias = np.zeros((1, layer_sizes[i + 1]))
            
            self.weights.append(weight)
            self.biases.append(bias)
    
    def _forward_pass(self, X):
        """Forward pass through the network"""
        activations = [X]
        z_values = []
        
        for i in range(len(self.weights)):
            z = np.dot(activations[-1], self.weights[i]) + self.biases[i]
            z_values.append(z)
            
            if i < len(self.weights) - 1:  # Hidden layers
                a = self._relu(z)
            else:  # Output layer
                a = z  # Linear activation for regression
            
            activations.append(a)
        
        return activations, z_values
    
    def _backward_pass(self, X, y, activations, z_values):
        """Backward pass (backpropagation)"""
        m = X.shape[0]
        gradients_w = []
        gradients_b = []
        
        # Output layer error
        dz = activations[-1] - y.reshape(-1, 1)
        
        for i in reversed(range(len(self.weights))):
            # Gradients for weights and biases
            dw = (1/m) * np.dot(activations[i].T, dz)
            db = (1/m) * np.sum(dz, axis=0, keepdims=True)
            
            gradients_w.insert(0, dw)
            gradients_b.insert(0, db)
            
            if i > 0:
                # Error for previous layer
                dz = np.dot(dz, self.weights[i].T) * self._relu_derivative(z_values[i-1])
        
        return gradients_w, gradients_b
    
    def train(self, X: Union[np.ndarray, pd.DataFrame], 
              y: Union[np.ndarray, pd.Series],
              verbose: bool = True) -> bool:
        """
        Train the neural network
        
        Args:
            X: Training features
            y: Training targets
            verbose: Whether to print training progress
            
        Returns:
            True if training successful, False otherwise
        """
        try:
            if verbose:
                print("🚀 Starting Simple Neural Network training...")
            
            # Convert to numpy arrays
            if isinstance(X, pd.DataFrame):
                self.feature_names = list(X.columns)
                X = X.values
            else:
                self.feature_names = [f'feature_{i}' for i in range(X.shape[1])]
            
            if isinstance(y, pd.Series):
                y = y.values
            
            # Store feature count
            self.n_features = X.shape[1]
            
            # Standardize features
            X_scaled = self._standardize(X, fit=True)
            
            # Initialize weights
            self._init_weights(self.n_features)
            
            # Training loop
            self.training_losses = []
            
            for epoch in range(self.epochs):
                # Forward pass
                activations, z_values = self._forward_pass(X_scaled)
                
                # Calculate loss (MSE)
                predictions = activations[-1].flatten()
                loss = np.mean((predictions - y) ** 2)
                self.training_losses.append(loss)
                
                # Backward pass
                gradients_w, gradients_b = self._backward_pass(X_scaled, y, activations, z_values)
                
                # Update weights and biases
                for i in range(len(self.weights)):
                    self.weights[i] -= self.learning_rate * gradients_w[i]
                    self.biases[i] -= self.learning_rate * gradients_b[i]
                
                # Print progress
                if verbose and (epoch + 1) % (self.epochs // 10) == 0:
                    print(f"Epoch {epoch + 1}/{self.epochs}, Loss: {loss:.6f}")
            
            self.is_trained = True
            
            if verbose:
                print("✅ Simple Neural Network training completed!")
                print(f"📊 Final Loss: {self.training_losses[-1]:.6f}")
            
            return True
            
        except Exception as e:
            print(f"❌ Training failed: {e}")
            return False
    
    def predict(self, X: Union[np.ndarray, pd.DataFrame]) -> np.ndarray:
        """
        Make predictions using the trained model
        
        Args:
            X: Features for prediction
            
        Returns:
            Predicted values
        """
        try:
            if not self.is_trained:
                raise ValueError("Model must be trained before making predictions")
            
            # Convert to numpy array
            if isinstance(X, pd.DataFrame):
                X = X.values
            
            # Standardize features
            X_scaled = self._standardize(X, fit=False)
            
            # Forward pass
            activations, _ = self._forward_pass(X_scaled)
            
            return activations[-1].flatten()
            
        except Exception as e:
            print(f"❌ Prediction failed: {e}")
            return np.array([])
    
    def evaluate(self, X: Union[np.ndarray, pd.DataFrame], 
                 y: Union[np.ndarray, pd.Series]) -> Dict[str, float]:
        """
        Evaluate model performance
        
        Args:
            X: Test features
            y: Test targets
            
        Returns:
            Dictionary with evaluation metrics
        """
        try:
            if not self.is_trained:
                raise ValueError("Model must be trained before evaluation")
            
            # Make predictions
            y_pred = self.predict(X)
            
            # Convert to numpy
            if isinstance(y, pd.Series):
                y = y.values
            
            # Calculate metrics
            metrics = {}
            
            if SKLEARN_AVAILABLE:
                metrics['mse'] = float(mean_squared_error(y, y_pred))
                metrics['rmse'] = float(np.sqrt(metrics['mse']))
                metrics['mae'] = float(mean_absolute_error(y, y_pred))
                metrics['r2_score'] = float(r2_score(y, y_pred))
            else:
                # Manual calculations
                metrics['mse'] = float(np.mean((y - y_pred) ** 2))
                metrics['rmse'] = float(np.sqrt(metrics['mse']))
                metrics['mae'] = float(np.mean(np.abs(y - y_pred)))
                
                # R2 score
                ss_res = np.sum((y - y_pred) ** 2)
                ss_tot = np.sum((y - np.mean(y)) ** 2)
                metrics['r2_score'] = float(1 - (ss_res / ss_tot)) if ss_tot > 0 else 0.0
            
            # Financial-specific metrics
            metrics['mape'] = float(np.mean(np.abs((y - y_pred) / (y + 1e-8))) * 100)
            metrics['financial_accuracy'] = float(np.mean(np.abs((y - y_pred) / (y + 1e-8)) <= 0.1) * 100)
            metrics['n_samples'] = len(y)
            
            return metrics
            
        except Exception as e:
            print(f"❌ Model evaluation failed: {e}")
            return {}
    
    def get_training_history(self) -> Dict[str, List[float]]:
        """Get training loss history"""
        return {'loss': self.training_losses}
    
    def get_model_summary(self) -> Dict[str, Any]:
        """Get model summary"""
        try:
            total_params = sum(w.size for w in self.weights) + sum(b.size for b in self.biases)
            
            summary = {
                'model_type': 'Simple Neural Network',
                'is_trained': self.is_trained,
                'n_features': self.n_features,
                'feature_names': self.feature_names,
                'architecture': {
                    'hidden_layers': self.hidden_layers,
                    'total_parameters': total_params
                },
                'training_params': {
                    'learning_rate': self.learning_rate,
                    'epochs': self.epochs
                }
            }
            
            if self.training_losses:
                summary['final_loss'] = float(self.training_losses[-1])
                summary['training_epochs'] = len(self.training_losses)
            
            return summary
            
        except Exception as e:
            print(f"❌ Model summary generation failed: {e}")
            return {'error': str(e)}
    
    def save_model(self, filepath: str) -> bool:
        """Save the trained model"""
        try:
            if not self.is_trained:
                print("❌ Cannot save untrained model")
                return False
            
            model_data = {
                'weights': self.weights,
                'biases': self.biases,
                'feature_names': self.feature_names,
                'n_features': self.n_features,
                'scaler_mean': self.scaler_mean,
                'scaler_std': self.scaler_std,
                'hidden_layers': self.hidden_layers,
                'learning_rate': self.learning_rate,
                'epochs': self.epochs,
                'training_losses': self.training_losses
            }
            
            with open(f"{filepath}.pkl", 'wb') as f:
                pickle.dump(model_data, f)
            
            print(f"✅ Model saved to {filepath}.pkl")
            return True
            
        except Exception as e:
            print(f"❌ Model save failed: {e}")
            return False
    
    def load_model(self, filepath: str) -> bool:
        """Load a saved model"""
        try:
            with open(f"{filepath}.pkl", 'rb') as f:
                model_data = pickle.load(f)
            
            self.weights = model_data['weights']
            self.biases = model_data['biases']
            self.feature_names = model_data['feature_names']
            self.n_features = model_data['n_features']
            self.scaler_mean = model_data['scaler_mean']
            self.scaler_std = model_data['scaler_std']
            self.hidden_layers = model_data['hidden_layers']
            self.learning_rate = model_data['learning_rate']
            self.epochs = model_data['epochs']
            self.training_losses = model_data.get('training_losses', [])
            
            self.is_trained = True
            
            print(f"✅ Model loaded from {filepath}.pkl")
            return True
            
        except Exception as e:
            print(f"❌ Model load failed: {e}")
            return False

# Backward compatibility - create NeuralNetworkRegressor alias
class NeuralNetworkRegressor(SimpleNeuralNetwork):
    """Alias for SimpleNeuralNetwork to maintain compatibility"""
    def __init__(self, hidden_layers=None, **kwargs):
        if hidden_layers is None:
            hidden_layers = [128, 64, 32]
        super().__init__(hidden_layers=hidden_layers, **kwargs)

# Test the Simple Neural Network
if __name__ == "__main__":
    print("🧠 Testing Simple Neural Network...")
    
    # Generate synthetic financial data
    np.random.seed(42)
    n_samples = 1000
    n_features = 15
    
    # Synthetic features representing financial indicators
    X = np.random.randn(n_samples, n_features)
    
    # Create synthetic target (financial health score)
    y = (
        X[:, 0] * 2.5 +                    # Revenue factor
        X[:, 1] * 1.8 +                    # Profit margin
        X[:, 2] * (-1.2) +                 # Debt ratio (negative impact)
        X[:, 3] * X[:, 4] * 0.5 +          # Interaction term
        np.sin(X[:, 5]) * 0.8 +            # Non-linear relationship
        np.random.randn(n_samples) * 0.3    # Noise
    )
    
    # Create DataFrame
    feature_names = [
        'revenue_growth', 'profit_margin', 'debt_ratio', 'liquidity_ratio', 'roa',
        'current_ratio', 'quick_ratio', 'inventory_turnover', 'receivables_turnover',
        'payables_turnover', 'cash_ratio', 'interest_coverage', 'debt_to_equity',
        'working_capital', 'market_cap'
    ]
    
    X_df = pd.DataFrame(X, columns=feature_names)
    y_series = pd.Series(y, name='financial_health_score')
    
    # Split data
    if SKLEARN_AVAILABLE:
        X_train, X_test, y_train, y_test = train_test_split(
            X_df, y_series, test_size=0.2, random_state=42
        )
    else:
        # Manual split
        train_idx = int(0.8 * len(X_df))
        X_train = X_df[:train_idx]
        X_test = X_df[train_idx:]
        y_train = y_series[:train_idx]
        y_test = y_series[train_idx:]
    
    print(f"📊 Dataset: {len(X_train)} train, {len(X_test)} test samples")
    
    # Test the model
    try:
        # Create model
        model = SimpleNeuralNetwork(
            hidden_layers=[64, 32],
            learning_rate=0.01,
            epochs=50
        )
        
        # Train model
        success = model.train(X_train, y_train, verbose=True)
        
        if success:
            print("✅ Training successful")
            
            # Make predictions
            y_pred = model.predict(X_test)
            print(f"✅ Predictions shape: {y_pred.shape}")
            
            # Evaluate model
            metrics = model.evaluate(X_test, y_test)
            print(f"📊 R² Score: {metrics.get('r2_score', 0):.4f}")
            print(f"📊 RMSE: {metrics.get('rmse', 0):.4f}")
            print(f"📊 Financial Accuracy: {metrics.get('financial_accuracy', 0):.2f}%")
            
            # Test save/load
            model.save_model("test_model")
            
            # Load model
            new_model = SimpleNeuralNetwork()
            if new_model.load_model("test_model"):
                print("✅ Model save/load working")
        
        else:
            print("❌ Training failed")
            
    except Exception as e:
        print(f"❌ Test failed: {e}")
    
    print("🎉 Simple Neural Network Test Completed!")