from datetime import datetime
import numpy as np # type: ignore

def safe_float(value, default=0.0):
    """Safely convert value to float"""
    if value is None:
        return default
    try:
        return float(value)
    except (ValueError, TypeError):
        return default

def safe_int(value, default=0):
    """Safely convert value to int"""
    if value is None:
        return default
    try:
        return int(float(value))
    except (ValueError, TypeError):
        return default

def format_currency(value):
    """Format currency values"""
    if value is None:
        return 'N/A'
    
    try:
        value = float(value)
        if value >= 1e12:
            return f"${value/1e12:.1f}T"
        elif value >= 1e9:
            return f"${value/1e9:.1f}B"
        elif value >= 1e6:
            return f"${value/1e6:.1f}M"
        elif value >= 1e3:
            return f"${value/1e3:.1f}K"
        else:
            return f"${value:.2f}"
    except (ValueError, TypeError):
        return 'N/A'

def calculate_cash_flow_health_score(company_data):
    """Calculate financial health score based on cash flow statement data"""
    score = 50  # Base score
    
    try:
        # Operating cash flow impact (30% weight)
        ocf = safe_float(company_data.get('net_cash_from_operating_activities'))
        if ocf > 1000000:  # > $1M
            score += 20
        elif ocf > 0:
            score += 10
        elif ocf < -1000000:  # < -$1M
            score -= 25
        elif ocf < 0:
            score -= 15
        
        # Net income impact (25% weight)
        net_income = safe_float(company_data.get('net_income'))
        if net_income > 500000:  # > $500K
            score += 15
        elif net_income > 0:
            score += 8
        elif net_income < -500000:  # < -$500K
            score -= 20
        elif net_income < 0:
            score -= 12
        
        # Free cash flow impact (25% weight)
        fcf = safe_float(company_data.get('free_cash_flow'))
        if fcf > 500000:  # > $500K
            score += 15
        elif fcf > 0:
            score += 8
        elif fcf < -500000:  # < -$500K
            score -= 15
        elif fcf < 0:
            score -= 8
        
        # Liquidation warning impact (20% weight)
        liquidation_label = safe_int(company_data.get('liquidation_label'))
        if liquidation_label == 1:
            score -= 20
        else:
            score += 10
        
        return max(0, min(100, round(score)))
        
    except Exception as e:
        print(f"Error calculating health score: {e}")
        return 50

def get_cash_flow_status_from_amount(ocf_amount):
    """Determine cash flow status from operating cash flow amount"""
    try:
        ocf = safe_float(ocf_amount)
        if ocf > 5000000:  # > $5M
            return 'excellent'
        elif ocf > 1000000:  # > $1M
            return 'good'
        elif ocf > 0:  # Positive but less than $1M
            return 'moderate'
        else:  # Negative or zero
            return 'poor'
    except:
        return 'poor'

def get_profitability_status_from_amount(net_income_amount):
    """Determine profitability status from net income amount"""
    try:
        net_income = safe_float(net_income_amount)
        if net_income > 2000000:  # > $2M
            return 'excellent'
        elif net_income > 500000:  # > $500K
            return 'good'
        elif net_income > 0:  # Positive but less than $500K
            return 'moderate'
        else:  # Negative or zero
            return 'poor'
    except:
        return 'poor'

def map_industry_to_sector(industry):
    """Map industry to broader sector categories"""
    if not industry:
        return 'General'
    
    industry_lower = industry.lower()
    
    # Technology sector
    tech_keywords = ['software', 'technology', 'computer', 'internet', 'digital', 'tech', 'it services']
    if any(keyword in industry_lower for keyword in tech_keywords):
        return 'Technology'
    
    # Healthcare sector
    healthcare_keywords = ['healthcare', 'medical', 'pharmaceutical', 'biotech', 'drug', 'hospital', 'health']
    if any(keyword in industry_lower for keyword in healthcare_keywords):
        return 'Healthcare'
    
    # Financial sector
    financial_keywords = ['financial', 'bank', 'insurance', 'investment', 'asset management', 'credit']
    if any(keyword in industry_lower for keyword in financial_keywords):
        return 'Financial'
    
    # Industrial sector
    industrial_keywords = ['manufacturing', 'industrial', 'construction', 'machinery', 'aerospace', 'defense']
    if any(keyword in industry_lower for keyword in industrial_keywords):
        return 'Industrial'
    
    # Consumer sector
    consumer_keywords = ['retail', 'consumer', 'food', 'beverage', 'clothing', 'entertainment']
    if any(keyword in industry_lower for keyword in consumer_keywords):
        return 'Consumer'
    
    # Energy sector
    energy_keywords = ['energy', 'oil', 'gas', 'renewable', 'utilities', 'power']
    if any(keyword in industry_lower for keyword in energy_keywords):
        return 'Energy'
    
    return 'General'