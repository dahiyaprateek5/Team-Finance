import openai # type: ignore
import json
from datetime import datetime
from config.settings import Config

openai.api_key = Config.OPENAI_API_KEY

def get_chatgpt_recommendations_service(request):
    """Get AI recommendations from ChatGPT based on financial data"""
    try:
        request_data = request.get_json()
        financial_data = request_data.get('financial_data')
        
        if not financial_data:
            return jsonify({ # type: ignore
                'success': False,
                'error': 'No financial data provided'
            }), 400
        
        # Prepare prompt for ChatGPT
        financial_summary = financial_data.get('financial_summary', {})
        company_name = financial_summary.get('company_overview', {}).get('name', 'the company')
        
        # Build prompt
        prompt = f"""
        You are a senior financial analyst providing recommendations for {company_name}.
        
        Based on the financial data provided, give exactly 3-5 actionable recommendations in JSON format:
        [
          {{
            "priority": "high|medium|low",
            "category": "Category Name",
            "title": "Action Title",
            "description": "What to do",
            "impact": "Expected impact",
            "timeline": "Timeframe",
            "icon": "fa-icon-name"
          }}
        ]
        """
        
        # Call OpenAI API
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a financial analyst. Provide JSON only."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1500,
            temperature=0.7
        )
        
        ai_response = response.choices[0].message.content.strip()
        
        # Parse JSON response
        try:
            recommendations = json.loads(ai_response)
        except json.JSONDecodeError:
            # Fallback recommendations
            recommendations = [
                {
                    "priority": "high",
                    "category": "Cash Flow Management",
                    "title": "Optimize Working Capital",
                    "description": "Review accounts receivable and payable cycles",
                    "impact": "10-15% cash flow improvement",
                    "timeline": "2-4 weeks",
                    "icon": "fa-chart-line"
                }
            ]
        
        return jsonify({  # type: ignore
            'success': True,
            'recommendations': recommendations,
            'ai_model': 'gpt-3.5-turbo',
            'generated_at': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({   # type: ignore
            'success': False,
            'error': f'Error generating recommendations: {str(e)}'
        }), 500