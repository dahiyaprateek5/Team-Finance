# =====================================
# ANALYTICS DASHBOARD ROUTES
# File: analytics/dashboard_routes.py
# =====================================

from flask import Blueprint, render_template, jsonify, request # type: ignore
from datetime import datetime
import sys
import os

# Add database connection path
sys.path.append('DATABASE_CONNECTION')
from db_connection import DatabaseConnection
from db_operations import DatabaseOperations

# Create blueprint for analytics
analytics_bp = Blueprint('analytics', __name__, url_prefix='/analytics')

# Database connection
db_conn = DatabaseConnection()

# =====================================
# UTILITY FUNCTIONS
# =====================================

def safe_float(value, default=0.0):
    """Safely convert value to float"""
    if value is None:
        return default
    try:
        return float(value)
    except (ValueError, TypeError):
        return default

def calculate_financial_health_score(data):
    """Calculate comprehensive financial health score"""
    score = 50  # Base score
    
    try:
        # Operating cash flow (30% weight)
        ocf = safe_float(data.get('net_cash_from_operating_activities'))
        if ocf > 1000000:
            score += 20
        elif ocf > 0:
            score += 10
        elif ocf < 0:
            score -= 15
        
        # Net income (25% weight)
        net_income = safe_float(data.get('net_income'))
        if net_income > 500000:
            score += 15
        elif net_income > 0:
            score += 8
        elif net_income < 0:
            score -= 12
        
        # Free cash flow (25% weight)
        fcf = safe_float(data.get('free_cash_flow'))
        if fcf > 500000:
            score += 15
        elif fcf > 0:
            score += 8
        elif fcf < 0:
            score -= 8
        
        # Liquidation risk (20% weight)
        liquidation = safe_float(data.get('liquidation_label'))
        if liquidation == 1:
            score -= 20
        else:
            score += 10
        
        return max(0, min(100, round(score)))
    except:
        return 50

def generate_radar_chart_data(company_data):
    """Generate data for financial health radar chart"""
    try:
        # Calculate 5 dimensions for radar chart
        liquidity_score = 70  # Default
        profitability_score = calculate_profitability_score(company_data)
        debt_score = calculate_debt_management_score(company_data)
        cash_flow_score = calculate_cash_flow_score(company_data)
        stability_score = calculate_stability_score(company_data)
        
        return {
            'labels': ['Liquidity', 'Profitability', 'Debt Management', 'Cash Flow', 'Stability'],
            'scores': [liquidity_score, profitability_score, debt_score, cash_flow_score, stability_score],
            'overall_score': round((liquidity_score + profitability_score + debt_score + cash_flow_score + stability_score) / 5)
        }
    except Exception as e:
        print(f"Error generating radar chart data: {e}")
        return {
            'labels': ['Liquidity', 'Profitability', 'Debt Management', 'Cash Flow', 'Stability'],
            'scores': [50, 50, 50, 50, 50],
            'overall_score': 50
        }

def calculate_profitability_score(data):
    """Calculate profitability score (0-100)"""
    net_income = safe_float(data.get('net_income'))
    if net_income > 2000000:
        return 90
    elif net_income > 500000:
        return 75
    elif net_income > 0:
        return 60
    elif net_income > -500000:
        return 30
    else:
        return 10

def calculate_debt_management_score(data):
    """Calculate debt management score (0-100)"""
    debt_ratio = safe_float(data.get('debt_to_equity_ratio'))
    if debt_ratio == 0:
        return 85
    elif debt_ratio < 0.5:
        return 80
    elif debt_ratio < 1.0:
        return 65
    elif debt_ratio < 2.0:
        return 45
    else:
        return 20

def calculate_cash_flow_score(data):
    """Calculate cash flow score (0-100)"""
    ocf = safe_float(data.get('net_cash_from_operating_activities'))
    if ocf > 5000000:
        return 95
    elif ocf > 1000000:
        return 80
    elif ocf > 0:
        return 65
    elif ocf > -1000000:
        return 30
    else:
        return 15

def calculate_stability_score(data):
    """Calculate financial stability score (0-100)"""
    # Based on multiple factors
    base_score = 60
    
    # Adjust based on liquidation label
    if safe_float(data.get('liquidation_label')) == 1:
        base_score -= 30
    else:
        base_score += 10
    
    # Adjust based on interest coverage
    interest_coverage = safe_float(data.get('interest_coverage_ratio'))
    if interest_coverage > 5:
        base_score += 20
    elif interest_coverage > 2:
        base_score += 10
    elif interest_coverage < 1:
        base_score -= 20
    
    return max(0, min(100, base_score))

def generate_trend_data(company_name):
    """Generate trend analysis data"""
    try:
        # Get multi-year data for trend analysis
        trend_query = """
        SELECT year, net_income, net_cash_from_operating_activities, 
               free_cash_flow, debt_to_equity_ratio
        FROM cash_flow_statement 
        WHERE company_name = %s 
        ORDER BY year ASC
        """
        
        trend_data = db_conn.execute_query(trend_query, (company_name,))
        
        if not trend_data:
            return None
        
        # Format data for charts
        years = [str(row['year']) for row in trend_data]
        net_income = [safe_float(row['net_income']) / 1000000 for row in trend_data]  # Convert to millions
        cash_flow = [safe_float(row['net_cash_from_operating_activities']) / 1000000 for row in trend_data]
        free_cash_flow = [safe_float(row['free_cash_flow']) / 1000000 for row in trend_data]
        debt_ratio = [safe_float(row['debt_to_equity_ratio']) for row in trend_data]
        
        return {
            'years': years,
            'net_income': net_income,
            'cash_flow': cash_flow,
            'free_cash_flow': free_cash_flow,
            'debt_ratio': debt_ratio
        }
        
    except Exception as e:
        print(f"Error generating trend data: {e}")
        return None

def generate_ai_insights(company_data):
    """Generate AI-powered insights and recommendations"""
    insights = []
    recommendations = []
    
    try:
        # Analyze cash flow
        ocf = safe_float(company_data.get('net_cash_from_operating_activities'))
        if ocf < 0:
            insights.append("⚠️ Negative operating cash flow detected")
            recommendations.append("Focus on improving collection processes and reducing operational expenses")
        elif ocf > 5000000:
            insights.append("✅ Strong operating cash flow performance")
            recommendations.append("Consider investment opportunities for excess cash")
        
        # Analyze profitability
        net_income = safe_float(company_data.get('net_income'))
        if net_income < 0:
            insights.append("📉 Company is currently operating at a loss")
            recommendations.append("Implement cost reduction strategies and revenue optimization")
        elif net_income > 2000000:
            insights.append("💰 Excellent profitability performance")
            recommendations.append("Maintain current strategies and explore expansion opportunities")
        
        # Analyze debt
        debt_ratio = safe_float(company_data.get('debt_to_equity_ratio'))
        if debt_ratio > 2:
            insights.append("⚠️ High debt-to-equity ratio")
            recommendations.append("Consider debt restructuring or equity financing")
        elif debt_ratio < 0.5:
            insights.append("💪 Conservative debt management")
            recommendations.append("Potential to leverage debt for growth opportunities")
        
        # Liquidation risk
        if safe_float(company_data.get('liquidation_label')) == 1:
            insights.append("🚨 Liquidation risk identified")
            recommendations.append("Immediate action required: Consider emergency financing and cost reduction")
        
        return {
            'insights': insights[:5],  # Limit to top 5
            'recommendations': recommendations[:5],
            'risk_level': 'High' if len([i for i in insights if '🚨' in i or '⚠️' in i]) > 0 else 'Medium' if len([i for i in insights if '📉' in i]) > 0 else 'Low'
        }
        
    except Exception as e:
        print(f"Error generating AI insights: {e}")
        return {
            'insights': ['Analysis in progress...'],
            'recommendations': ['Please check back later for detailed recommendations'],
            'risk_level': 'Medium'
        }

# =====================================
# MAIN DASHBOARD ROUTES
# =====================================

@analytics_bp.route('/dashboard/<company_name>')
def main_dashboard(company_name):
    """Main analytics dashboard for a specific company"""
    try:
        print(f"📊 Loading analytics dashboard for {company_name}")
        
        # Get latest company financial data
        company_query = """
        SELECT * FROM cash_flow_statement 
        WHERE company_name = %s 
        ORDER BY year DESC 
        LIMIT 1
        """
        
        company_result = db_conn.execute_query(company_query, (company_name,))
        
        if not company_result:
            return render_template('analytics/main_dashboard.html', 
                                 error=f"No financial data found for {company_name}",
                                 company_name=company_name)
        
        company_data = company_result[0]
        
        # Generate dashboard data
        radar_data = generate_radar_chart_data(company_data)
        trend_data = generate_trend_data(company_name)
        ai_insights = generate_ai_insights(company_data)
        overall_health = calculate_financial_health_score(company_data)
        
        # Dashboard summary data
        dashboard_data = {
            'company_name': company_name,
            'overall_health_score': overall_health,
            'last_analysis': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'financial_year': company_data.get('year', 2024),
            'radar_chart': radar_data,
            'trend_analysis': trend_data,
            'ai_insights': ai_insights,
            'key_metrics': {
                'net_income': company_data.get('net_income', 0),
                'operating_cash_flow': company_data.get('net_cash_from_operating_activities', 0),
                'free_cash_flow': company_data.get('free_cash_flow', 0),
                'debt_ratio': company_data.get('debt_to_equity_ratio', 0),
                'liquidation_risk': company_data.get('liquidation_label', 0)
            }
        }
        
        print(f"✅ Analytics dashboard loaded successfully for {company_name}")
        
        return render_template('analytics/main_dashboard.html', 
                             dashboard=dashboard_data,
                             company_name=company_name)
                             
    except Exception as e:
        print(f"❌ Error loading analytics dashboard: {e}")
        return render_template('analytics/main_dashboard.html', 
                             error=f"Error loading dashboard: {str(e)}",
                             company_name=company_name)

# =====================================
# API ENDPOINTS FOR CHART DATA
# =====================================

@analytics_bp.route('/api/radar-chart/<company_name>')
def get_radar_chart_data(company_name):
    """API endpoint for radar chart data"""
    try:
        company_query = """
        SELECT * FROM cash_flow_statement 
        WHERE company_name = %s 
        ORDER BY year DESC 
        LIMIT 1
        """
        
        result = db_conn.execute_query(company_query, (company_name,))
        
        if not result:
            return jsonify({'error': 'Company not found'}), 404
        
        radar_data = generate_radar_chart_data(result[0])
        
        return jsonify({
            'success': True,
            'data': radar_data
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@analytics_bp.route('/api/trend-analysis/<company_name>')
def get_trend_analysis_data(company_name):
    """API endpoint for trend analysis data"""
    try:
        trend_data = generate_trend_data(company_name)
        
        if not trend_data:
            return jsonify({'error': 'No trend data available'}), 404
        
        return jsonify({
            'success': True,
            'data': trend_data
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@analytics_bp.route('/api/ai-insights/<company_name>')
def get_ai_insights_data(company_name):
    """API endpoint for AI insights"""
    try:
        company_query = """
        SELECT * FROM cash_flow_statement 
        WHERE company_name = %s 
        ORDER BY year DESC 
        LIMIT 1
        """
        
        result = db_conn.execute_query(company_query, (company_name,))
        
        if not result:
            return jsonify({'error': 'Company not found'}), 404
        
        insights = generate_ai_insights(result[0])
        
        return jsonify({
            'success': True,
            'data': insights
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@analytics_bp.route('/api/financial-summary/<company_name>')
def get_financial_summary(company_name):
    """API endpoint for financial summary"""
    try:
        summary_query = """
        SELECT 
            company_name,
            year,
            net_income,
            net_cash_from_operating_activities,
            free_cash_flow,
            debt_to_equity_ratio,
            liquidation_label,
            industry
        FROM cash_flow_statement 
        WHERE company_name = %s 
        ORDER BY year DESC 
        LIMIT 1
        """
        
        result = db_conn.execute_query(summary_query, (company_name,))
        
        if not result:
            return jsonify({'error': 'Company not found'}), 404
        
        data = result[0]
        health_score = calculate_financial_health_score(data)
        
        return jsonify({
            'success': True,
            'company_name': company_name,
            'financial_data': dict(data),
            'health_score': health_score,
            'generated_at': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# =====================================
# DASHBOARD MANAGEMENT ROUTES
# =====================================

@analytics_bp.route('/companies')
def list_companies():
    """List all companies available for analytics"""
    try:
        companies_query = """
        SELECT DISTINCT company_name, industry, 
               COUNT(*) as years_data,
               MAX(year) as latest_year
        FROM cash_flow_statement 
        GROUP BY company_name, industry
        ORDER BY company_name
        """
        
        companies = db_conn.execute_query(companies_query)
        
        return render_template('analytics/companies_list.html', 
                             companies=companies if companies else [])
                             
    except Exception as e:
        print(f"❌ Error loading companies list: {e}")
        return render_template('analytics/companies_list.html', 
                             companies=[], 
                             error=str(e))

@analytics_bp.route('/health')
def analytics_health_check():
    """Health check for analytics module"""
    try:
        # Test database connection
        db_conn.execute_query("SELECT 1")
        
        # Test data availability
        companies_count_query = "SELECT COUNT(DISTINCT company_name) as count FROM cash_flow_statement"
        result = db_conn.execute_query(companies_count_query)
        companies_count = result[0]['count'] if result else 0
        
        return jsonify({
            'status': 'healthy',
            'database': 'connected',
            'companies_available': companies_count,
            'timestamp': datetime.now().isoformat(),
            'module': 'analytics_dashboard'
        })
        
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500